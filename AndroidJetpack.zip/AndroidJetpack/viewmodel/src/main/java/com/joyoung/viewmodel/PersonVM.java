package com.joyoung.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

public class PersonVM extends ViewModel {
    private MutableLiveData<Person> person;

    public LiveData<Person> getPerson() {
        if (person == null) {
            person = new MutableLiveData<Person>();
            loadPerson();
        }
        return person;
    }

    /**
     * 在这里初始化Person
     */
    private void loadPerson() {
        
    }
}
