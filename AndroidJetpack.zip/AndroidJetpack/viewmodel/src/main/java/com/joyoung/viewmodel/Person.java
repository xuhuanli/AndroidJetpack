package com.joyoung.viewmodel;

public class Person {
}
